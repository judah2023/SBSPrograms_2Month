﻿#include <iostream>
using namespace std;

int isPrimeTable[10001] = { 0 };

int main()
{
	fill(isPrimeTable[2], isPrimeTable[10000], 1);
	
	return 0;
}

